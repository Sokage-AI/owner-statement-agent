STEP 0 - GATE
 1. Reconciled and closed: YES, stated ("Status: RECONCILED / CLOSED").
 2. Exactly one owner: YES, Marcus Webb, on the approved owners list.
 3. Fee basis configured: NO. The operator config states "Management fee basis: [OPERATOR: not yet configured]." This export shows a Management fee line of 350.00 with memo "8%", but I cannot confirm that basis is correct or matches Marcus Webb's actual agreement because no fee basis has been configured for this operator.
 4. Period, beginning balance, and ending balance stated: YES. Period 2026-07-01 to 2026-07-31. Beginning balance 1,240.00. Ending balance 577.60.

GATE FAILED on item 3.

Per the Never List (item 14: "Assume a management fee basis. If it is not configured, you ask.") and Step 0 instructions, I cannot proceed. I am not inventorying, cross-checking, or drafting anything below this point.

Question for a human to answer before this export can be processed:
 What is Marcus Webb's management fee basis (for example: a percentage of rent collected, a percentage of rent billed, or a flat monthly fee), and does the 350.00 / "8%" management fee line in this export match that agreed basis?

STOPPED - no draft produced. Management fee basis not configured. Human action required.
