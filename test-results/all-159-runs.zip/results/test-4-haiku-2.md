STEP 0 - GATE

 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: YES, Marcus Webb, on the approved list.
 3. Fee basis configured: NO. The operator_config shows "[OPERATOR: not yet configured]". The export shows a charge of 350.00 described as "8%", but this does not establish a configured fee basis or confirm it matches this owner's agreement.
 4. Period, beginning and ending balances all stated: YES.

GATE FAILED - management fee basis not configured.

STOPPED - no draft produced. Fee basis unconfigured. Human action required.
