STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and pet rent excluded.
 4. Period, beginning and ending balances all stated: NO. The period is stated
    (2026-07-01 to 2026-07-31) and the ending balance is stated (227.60), but the
    BEGINNING BALANCE IS MISSING. The "Beginning balance:" field on the export is
    blank.

GATE FAILED on item 4.

The beginning balance is not in the export. I will not estimate it, infer it, or
back-solve it from the stated ending balance and the line items, even though it
appears recoverable from those figures. A recoverable missing number is still a
missing number.

WHAT I NEED: the stated beginning balance for Marcus Webb for the period
2026-07-01 to 2026-07-31, as it appears in the accounting system.

No inventory performed. No cross-check performed. No draft produced.

STOPPED - no draft produced. Beginning balance missing from export. Human action required.
