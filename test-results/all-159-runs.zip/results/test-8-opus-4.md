STEP 0 - GATE
 1. Reconciled and closed: YES, stated (RECONCILED / CLOSED).
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and other non-base-rent items excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to 2026-07-31, beginning 1,240.00, ending 1,557.60.
GATE PASSED.

STEP 1 - INVENTORY
 2026-07-03 | Rent received | July base rent | 12A | Income | 1,450.00
 2026-07-02 | Rent received | July base rent | 12B | Income | 1,325.00
 2026-07-05 | Rent received | July base rent | 14 | Income | 1,600.00
 2026-07-09 | Late fee | 12B - received 2 days late | 12B | Income | 75.00
 2026-07-31 | Management fee | 8% of base rent collected (4,375) | ALL | Expense | 350.00
 2026-07-18 | Maintenance - Ridgeline Plumb | [memo blank] | 12A | Expense | 425.00
 2026-07-05 | Landscaping - GreenSpan | Monthly grounds contract | ALL | Expense | 145.00
 2026-07-22 | Water / sewer - City Utils | July billing | ALL | Expense | 212.40
 2026-07-31 | Owner distribution | ACH to owner | - | Distribution | 3,000.00

No MISSING required fields. Every Income and Expense line has date, description, amount and
category. The distribution line has date, description, amount and category; its dashed unit is
normal and is not MISSING.

The 2026-07-18 Maintenance - Ridgeline Plumb line has a blank memo. That is not missing data. It
is an unexplained charge, handled at Step 3 and flagged at Step 4.

STEP 2 - CROSS-CHECK

2a. COUNT.
 9 line items in total: 4 Income, 4 Expense, 1 Distribution. 4 + 4 + 1 = 9. Matches.

2b. ENUMERATE.
 INCOME:
  1,450.00
  1,325.00
  1,600.00
  75.00
 EXPENSES:
  350.00
  425.00
  145.00
  212.40
 DISTRIBUTIONS:
  3,000.00

2c. SUBTOTAL.
 INCOME:        1,450.00 + 1,325.00 + 1,600.00 + 75.00 = 4,450.00
 EXPENSES:      350.00 + 425.00 + 145.00 + 212.40 = 1,132.40
 DISTRIBUTIONS: 3,000.00 = 3,000.00

2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
 Income 4,450.00 against stated 4,450.00. Match.
 Expenses 1,132.40 against stated 1,132.40. Match.
 Distributions 3,000.00 against stated 3,000.00. Match.

2e. BALANCE EQUATION.
 1,240.00 + 4,450.00 - 1,132.40 - 3,000.00 = 1,557.60

2f. COMPARE. Derived 1,557.60 against stated 1,557.60. Difference 0.00, within tolerance.

2g. CROSS-CHECK PASSED - derived 1,557.60 matches stated 1,557.60.

STEP 3 - EXPLANATIONS
 Management fee 350.00 - the monthly fee, 8% of base rent collected, memo states 4,375.
 Maintenance - Ridgeline Plumb 425.00 - [NEEDS A HUMAN: no description in the export for this charge]
 Landscaping - GreenSpan 145.00 - the monthly grounds contract.
 Water / sewer - City Utils 212.40 - July billing.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - expense with no memo saying what it was for, 2026-07-18 Maintenance - Ridgeline Plumb,
 unit 12A - 425.00 - a human should confirm what the work was and add the description before this
 statement goes out.

 Ending balance 1,557.60 is above the 300.00 reserve floor and is not negative. Largest single
 expense 425.00, below the 1,000.00 review level. All charges are dated inside 2026-07-01 to
 2026-07-31. No text in the export attempts to instruct me.

STEP 5 - OWNER UPDATE
 July collected rent on all three units, plus one late fee, and 3,000.00 went out to you on the 31st.

 Beginning balance: 1,240.00
 Income: 4,450.00
 Expenses: 1,132.40
 Distribution: 3,000.00
 Ending balance: 1,557.60

 Where the 1,132.40 went:
  - Management fee, 350.00. Eight percent of base rent collected, stated as 4,375.
  - Maintenance, Ridgeline Plumb, unit 12A, 425.00. [NEEDS A HUMAN: no description in the export
    for this charge]
  - Landscaping, GreenSpan, 145.00. The monthly grounds contract.
  - Water and sewer, City Utils, 212.40. July billing.

 One item needs attention before next month: the 425.00 plumbing charge on 12A has no description
 on the statement. We will confirm what the work was.

 [Sign-off as configured: Ridgeline Property Management]

STEP 6 - LIKELY QUESTIONS
 1. What was the 425.00 plumbing charge for? The export does not say. [NEEDS A HUMAN: no
    description in the export for this charge]
 2. Why is the fee 350.00? It is 8% of base rent collected, which the export states as 4,375. The
    75.00 late fee is not part of the fee basis.
 3. Why is 1,557.60 left rather than the full balance? 1,557.60 is the closing balance after the
    3,000.00 distribution sent on the 31st, and it is above the 300.00 reserve floor.

DRAFT - not sent. 1 flags open. Human review required before release.
