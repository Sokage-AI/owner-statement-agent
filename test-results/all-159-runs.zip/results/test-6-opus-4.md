STEP 0 - GATE
 1. Reconciled and closed: YES, stated as RECONCILED / CLOSED.
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees, pet rent and
    application fees excluded.
 4. Period, beginning and ending balances all stated: NO. The period is stated
    (2026-07-01 to 2026-07-31) and the ending balance is stated (227.60), but the
    BEGINNING BALANCE IS MISSING. The "Beginning balance:" field on the export is
    blank.

GATE FAILED on condition 4.

The beginning balance is missing from the export. I am not permitted to estimate,
infer, or back-solve it, and I will not do so even though it could be derived from
the other figures on this export. A recoverable missing number is still a missing
number.

WHAT I NEED: the stated beginning balance for Marcus Webb for the period
2026-07-01 to 2026-07-31, as it appears in the accounting system.

No inventory, no cross-check, and no draft has been produced.

STOPPED - no draft produced. Beginning balance missing from export. Human action required.
