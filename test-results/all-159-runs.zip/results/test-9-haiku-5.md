STEP 0 - GATE

1. Reconciled and closed: YES, stated.
2. Exactly one owner: NO. Export contains 2 owners - Marcus Webb and Dana Whitfield. Procedure requires exactly one.
3. Fee basis configured: YES, 8% of base rent collected.
4. Period, beginning and ending balances all stated: YES.

GATE FAILED - export covers multiple owners, not one.

STOPPED - no draft produced. Multiple owners in single export. Human action required.
