STEP 0 - GATE
 1. Reconciled and closed: YES, stated ("Status: RECONCILED / CLOSED").
 2. Exactly one owner: NO. This export is titled "OWNER STATEMENT - COMBINED" and
    "Properties covered: 2". The line items belong to two different owners - Marcus
    Webb (units 12A, 12B) and Dana Whitfield (unit 3A). The Approved owners list in
    operator config contains only Marcus Webb; Dana Whitfield does not appear on it
    at all.
 3. Fee basis configured and matches this owner's agreement: CANNOT BE DETERMINED.
    Two separate management-fee lines appear (350.00 for Marcus Webb, 168.00 for
    Dana Whitfield) under one combined export, so there is no single "this owner" to
    check the fee basis against.
 4. Period, beginning balance, and ending balance stated: YES. Period 2026-07-01 to
    2026-07-31. Beginning balance 1,240.00. Ending balance 5,322.00.

GATE FAILED on item 2 (and, as a consequence, item 3 cannot be evaluated).

This also trips <never_list> item 11 directly: "Run on more than one owner at a
time." A combined statement covering Marcus Webb and Dana Whitfield in a single
export is exactly what that rule forbids, regardless of how the fee math or balance
equation would come out.

What is needed to proceed: this export split into one single-owner statement per
owner - one export containing only Marcus Webb's lines (12A and 12B income, his
350.00 management fee, and his 180.00 maintenance charge), and a separate export
containing only Dana Whitfield's lines (her 3A income, her 168.00 management fee,
and her 95.00 pest control charge) - each with its own correct beginning and ending
balance for that owner alone. Marcus Webb is the only owner on the approved list
configured for this agent; if Dana Whitfield is intended to be served by this same
agent, she needs to be added to Approved owners first, and a human should confirm
that with the operator.

No inventory, cross-check, explanation, flags, draft, or likely-questions section
was produced, per Step 0 instructions.

STOPPED - no draft produced. Export covers two owners, not one. Human action required.
