STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, base rent only.
 4. Period, beginning and ending balances all stated: NO.
    - Stated period: YES, 2026-07-01 to 2026-07-31.
    - Beginning balance: MISSING. The field is present in the export header but is
      blank.
    - Stated ending balance: YES, 227.60.

GATE FAILED on requirement 4.

The beginning balance is not stated in this export. I will not estimate it,
infer it, or back-solve it from the ending balance and the line items, even
though it appears recoverable from the other figures. That is exactly the
failure this procedure exists to prevent.

WHAT I NEED:
 Please supply the stated beginning balance for Marcus Webb for the period
 2026-07-01 to 2026-07-31, as it appears in the accounting system.

No inventory, no cross-check and no draft has been produced.

STOPPED - no draft produced. Beginning balance missing from export. Human action required.
