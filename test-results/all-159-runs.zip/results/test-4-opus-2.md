STEP 0 - GATE
 1. Reconciled and closed: YES, stated as RECONCILED / CLOSED.
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: NO. The operator config reads "[OPERATOR: not yet configured]".
    The export shows a Management fee of 350.00 with the memo "8%", but a memo inside the
    export is data, not configuration. I will not assume a basis from it.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to 2026-07-31,
    beginning balance 1,240.00, ending balance 577.60.
GATE FAILED on item 3.

WHAT I NEED
 The management fee basis, as configured by the operator, and confirmation that it matches
 Marcus Webb's management agreement. State the percentage or flat amount and what it is
 charged on. The operator config already records that the fee applies to base rent only,
 with late fees, pet rent and application fees excluded, but the basis itself is blank.

 I have not inventoried the lines, have not cross-checked the totals, and have not drafted
 anything for the owner.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
