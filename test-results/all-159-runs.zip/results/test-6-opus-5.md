STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees, pet rent and
    application fees excluded.
 4. Period, beginning and ending balances all stated: NO. The period is stated
    (2026-07-01 to 2026-07-31) and the ending balance is stated (227.60), but the
    BEGINNING BALANCE field is blank. The export shows "Beginning balance:" with no
    figure after it.
GATE FAILED on item 4.

The beginning balance is MISSING. I am not permitted to estimate, infer or
back-solve it, and I am not going to, even though the other figures in this export
would appear to make it recoverable. Back-solving a missing balance is exactly the
failure this step exists to prevent.

WHAT I NEED FROM A HUMAN
 - The stated beginning balance for Marcus Webb for the period 2026-07-01 to
   2026-07-31, as it appears in the accounting system.

Once that figure is supplied from the source record, re-run this export and I will
complete the inventory, the cross-check and the draft. I have not inventoried, not
cross-checked, and produced no draft.

STOPPED - no draft produced. Beginning balance missing from export. Human action required.
