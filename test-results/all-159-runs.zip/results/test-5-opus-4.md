STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees, pet rent and
    application fees excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-05-01 to
    2026-05-31, beginning 480.00, ending -612.00.
GATE PASSED.

STEP 1 - INVENTORY
 2026-05-03 | Rent received | May rent | 12A | Income | 1,450.00
 2026-05-31 | Management fee | 8% of rent collected | 12A | Expense | 116.00
 2026-05-11 | Emergency plumbing - Ridgeline | Burst supply line, water damage | 12A | Expense | 2,192.50
 2026-05-22 | Water / sewer - City Utils | May billing | 12A | Expense | 88.50
 2026-05-05 | Landscaping - GreenSpan | Monthly grounds contract | 12A | Expense | 145.00
No MISSING fields.

STEP 2 - CROSS-CHECK
2a. COUNT. 5 line items: 1 Income, 4 Expense, 0 Distribution. 1 + 4 + 0 = 5. Matches.
2b. ENUMERATE.
  INCOME:
    1,450.00
  EXPENSES:
    116.00
    2,192.50
    88.50
    145.00
  DISTRIBUTIONS:
    (no distribution line items in the export)
2c. SUBTOTAL.
  INCOME:        1,450.00 = 1,450.00
  EXPENSES:      116.00 + 2,192.50 + 88.50 + 145.00 = 2,542.00
  DISTRIBUTIONS: no lines to add = 0.00
2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
  Income 1,450.00 against stated 1,450.00. Match.
  Expenses 2,542.00 against stated 2,542.00. Match.
  Distributions 0.00 against stated 0.00. Match.
2e. BALANCE EQUATION.
  480.00 + 1,450.00 - 2,542.00 - 0.00 = -612.00
2f. COMPARE. Derived -612.00 against stated -612.00. Difference 0.00, within tolerance.
2g. CROSS-CHECK PASSED - derived -612.00 matches stated -612.00.

STEP 3 - EXPLANATIONS
 Management fee 116.00 - the monthly fee, stated in the memo as 8% of rent collected.
 Emergency plumbing 2,192.50 - burst supply line and water damage, Ridgeline, unit 12A.
 Water / sewer 88.50 - May billing, City Utils.
 Landscaping 145.00 - the monthly grounds contract, GreenSpan.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - negative owner balance - -612.00 - confirm how the shortfall is funded and
 what the owner is being asked to do about it before this goes out.
 FLAG - ending balance below the reserve floor - -612.00 against the 300.00 floor -
 confirm the reserve top-up amount and timing with the owner.
 FLAG - single expense at or above the 1,000.00 review level - 2,192.50 emergency
 plumbing, 2026-05-11 - check the invoice, the scope of the water damage work, and
 whether any part is an insurance claim or a tenant recharge.

 Context I could not check: the emergency plumbing vendor is named "Ridgeline", which
 is also the operator's own sign-off name in the configuration. The export does not
 say whether these are the same entity.

STEP 5 - OWNER UPDATE
 May closed with a negative balance of -612.00. An emergency plumbing repair of
 2,192.50 on the 11th was more than the month's rent, so the account is short and no
 distribution was made.

 Beginning balance: 480.00
 Income: 1,450.00
 Expenses: 2,542.00
 Distribution: 0.00
 Ending balance: -612.00

 Where the 2,542.00 went:
  - Emergency plumbing, 2,192.50. A burst supply line and the resulting water damage
    in 12A, done by Ridgeline on the 11th.
  - Landscaping, 145.00. The monthly grounds contract with GreenSpan.
  - Management fee, 116.00. Stated in the export as 8% of rent collected.
  - Water and sewer, 88.50. The May billing from City Utils.

 What this means: the account is 612.00 below zero and below the 300.00 reserve
 floor. Funds are needed to bring the account back above the reserve before next
 month's bills are paid.

 [Sign-off as configured: Ridgeline Property Management]

STEP 6 - LIKELY QUESTIONS
 1. Why is the balance negative? The 2,542.00 of expenses was more than the 1,450.00
    of rent collected plus the 480.00 you started with, which leaves -612.00.
 2. What was the 2,192.50 for? The export records it as a burst supply line and water
    damage in 12A, repaired by Ridgeline on 2026-05-11.
 3. Why was there no distribution this month? Distributions are stated as 0.00. There
    was nothing to send after the month's expenses.

DRAFT - not sent. 3 flags open. Human review required before release.
