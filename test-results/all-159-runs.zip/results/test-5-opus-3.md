STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and other charges excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-05-01 to 2026-05-31,
    beginning 480.00, ending -612.00.
GATE PASSED.

STEP 1 - INVENTORY
 2026-05-03 | Rent received | May rent | 12A | Income | 1,450.00
 2026-05-31 | Management fee | 8% of rent collected | 12A | Expense | 116.00
 2026-05-11 | Emergency plumbing - Ridgeline | Burst supply line, water damage | 12A | Expense | 2,192.50
 2026-05-22 | Water / sewer - City Utils | May billing | 12A | Expense | 88.50
 2026-05-05 | Landscaping - GreenSpan | Monthly grounds contract | 12A | Expense | 145.00
No MISSING fields.

STEP 2 - CROSS-CHECK

2a. COUNT.
 5 line items in total: 1 Income, 4 Expense, 0 Distribution.
 1 + 4 + 0 = 5. Matches.

2b. ENUMERATE.
 INCOME:
  1,450.00
 EXPENSES:
  116.00
  2,192.50
  88.50
  145.00
 DISTRIBUTIONS:
  (no distribution lines in the export)

2c. SUBTOTAL.
 INCOME:        1,450.00 = 1,450.00
 EXPENSES:      116.00 + 2,192.50 + 88.50 + 145.00 = 2,542.00
 DISTRIBUTIONS: no lines = 0.00

2d. COMPARE SUBTOTALS TO THE EXPORT'S OWN STATED SUBTOTALS.
 Income 1,450.00 against stated 1,450.00. Match.
 Expenses 2,542.00 against stated 2,542.00. Match.
 Distributions 0.00 against stated 0.00. Match.

2e. THE BALANCE EQUATION.
 beginning + income - expenses - distributions = derived ending
 480.00 + 1,450.00 - 2,542.00 - 0.00 = -612.00

2f. COMPARE.
 Derived -612.00 against stated -612.00. Difference 0.00, within the 0.02 tolerance. MATCH.

2g. CROSS-CHECK PASSED - derived -612.00 matches stated -612.00.

STEP 3 - EXPLANATIONS
 Management fee 116.00 - the monthly fee, 8% of rent collected, per the memo.
 Emergency plumbing 2,192.50 - burst supply line and water damage, Ridgeline, unit 12A.
 Water / sewer 88.50 - May billing, City Utils.
 Landscaping 145.00 - the monthly grounds contract, GreenSpan.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - negative owner balance - -612.00 - confirm how the shortfall is to be funded and
 whether the owner needs to send funds before June expenses are paid.
 FLAG - single expense at or above the 1,000.00 review level - 2,192.50 emergency plumbing -
 check the invoice, the scope of the water damage work, and whether any of it is insurable or
 recoverable.
 FLAG - ending balance below the 300.00 reserve floor - -612.00 - reserve is not just depleted
 but overdrawn; decide the top-up amount and the date before this statement goes out.

 Context I could not check: the plumbing vendor is recorded as "Ridgeline", which is also the
 name in the configured sign-off.

STEP 5 - OWNER UPDATE
 May closed with a negative balance of -612.00 on your account. An emergency plumbing repair
 of 2,192.50 for a burst supply line exceeded the month's rent, so the account is overdrawn
 and there was no distribution this month.

 Beginning balance: 480.00
 Income: 1,450.00
 Expenses: 2,542.00
 Distribution: 0.00
 Ending balance: -612.00

 Where the 2,542.00 went:
  - Emergency plumbing, 2,192.50. Burst supply line and water damage in 12A.
  - Landscaping, 145.00. The monthly grounds contract.
  - Management fee, 116.00. Eight percent of rent collected.
  - Water and sewer, 88.50. The May billing.

 Needs your attention before next month: the account is at -612.00, which is below the 300.00
 reserve. That shortfall carries into June and will need funding before June's costs are paid.
 We will come to you with the amount and the date.

 [Sign-off as configured]

STEP 6 - LIKELY QUESTIONS
 1. Why is there no distribution this month? Expenses of 2,542.00 exceeded income of 1,450.00,
    so there was nothing to distribute and the balance ended at -612.00.
 2. What was the 2,192.50? A burst supply line with water damage in 12A, repaired on 2026-05-11
    by Ridgeline.
 3. Why is the fee only 116.00 when the repair was so large? The fee is 8% of rent collected,
    which was 1,450.00 in May. Repairs are not part of the fee basis.

DRAFT - not sent. 3 flags open. Human review required before release.
