STEP 0 - GATE
 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: NO. The export contains Marcus Webb and Dana Whitfield.
 3. Fee basis configured: Not checked - gate failed.
 4. Period, beginning and ending balances all stated: YES.
GATE FAILED.

STOPPED - no draft produced. Multiple owners in export. Human action required.
