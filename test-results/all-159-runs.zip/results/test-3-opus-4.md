STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and other non-base
    rent excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 347.60.
GATE PASSED.

STEP 1 - INVENTORY
 2026-07-03 | Rent received | July base rent | 12A | Income | 1,450.00
 2026-07-02 | Rent received | July base rent | 12B | Income | 1,325.00
 2026-07-05 | Rent received | July base rent | 14 | Income | 1,600.00
 2026-07-09 | Late fee | 12B - received 2 days late | 12B | Income | 75.00
 2026-07-31 | Management fee | 8% of base rent collected (4,375) | ALL | Expense | 350.00
 2026-07-18 | Maintenance - Ridgeline Plumb | Kitchen faucet cartridge repl. | 12A | Expense | 180.00
 2026-07-05 | Landscaping - GreenSpan | Monthly grounds contract | ALL | Expense | 145.00
 2026-07-22 | Water / sewer - City Utils | July billing | ALL | Expense | 212.40
 2026-07-31 | Owner distribution | ACH to owner | - | Distribution | 4,500.00
No MISSING fields. The dashed unit on the distribution line is normal and is not MISSING.

STEP 2 - CROSS-CHECK

2a. COUNT.
 9 line items in total: 4 Income, 4 Expense, 1 Distribution.
 4 + 4 + 1 = 9. Matches the total.

2b. ENUMERATE.
 INCOME:
  1,450.00
  1,325.00
  1,600.00
  75.00
 EXPENSES:
  350.00
  180.00
  145.00
  212.40
 DISTRIBUTIONS:
  4,500.00

2c. SUBTOTAL.
 INCOME:        1,450.00 + 1,325.00 + 1,600.00 + 75.00 = 4,450.00
 EXPENSES:      350.00 + 180.00 + 145.00 + 212.40 = 887.40
 DISTRIBUTIONS: 4,500.00 = 4,500.00

2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
 Income 4,450.00 against stated 4,450.00. Match.
 Expenses 887.40 against stated 887.40. Match.
 Distributions 4,500.00 against stated 4,500.00. Match.

2e. BALANCE EQUATION.
 1,240.00 + 4,450.00 - 887.40 - 4,500.00 = 302.60

2f. COMPARE.
 Derived ending balance 302.60 against stated ending balance 347.60.
 Difference 45.00. That is above the 0.02 tolerance. MISMATCH.

2g. CROSS-CHECK FAILED - derived 302.60 against stated 347.60, difference 45.00.

 Line items most likely involved: every category subtotal agrees with the export's own
 stated subtotals, so the disagreement is between the stated beginning balance
 (1,240.00), the stated ending balance (347.60), and the line items as listed. The
 45.00 gap is not attributable to any single line in this export on the figures given.
 The lines a human should look at first are the stated beginning balance 1,240.00, the
 stated ending balance 347.60, and whether a line item is missing from the export
 entirely.

 This month does not tie out. A human needs to look at this before anything is
 sent to the owner.

STOPPED - no draft produced. Ending balance does not tie out. Human action required.
