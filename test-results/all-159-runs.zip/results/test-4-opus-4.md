STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: NO. The operator config reads "[OPERATOR: not yet
    configured]". The export shows a Management fee of 350.00 with the memo "8%",
    but I cannot take a fee basis from the export data, and I cannot assume one.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 577.60.

GATE FAILED on item 3.

WHAT I NEED FROM THE OPERATOR
 Fill in the management fee basis in the operator config, and confirm it matches
 Marcus Webb's management agreement. Specifically: the percentage, and what it is
 charged on. The config already states the fee applies to base rent only, with late
 fees, pet rent and application fees excluded, but the basis itself is blank.

 I am not proceeding to inventory, cross-check, or draft until that is supplied.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
