STEP 0 - GATE
 1. Reconciled and closed: YES, stated as "RECONCILED / CLOSED".
 2. Exactly one owner: NO. The export is labeled "OWNER STATEMENT - COMBINED" and lists two owners: Marcus Webb and Dana Whitfield. One statement per owner.
 3. Fee basis configured: YES, 8% of base rent collected, late fees excluded.
 4. Period, beginning and ending balances all stated: YES.
GATE FAILED - condition 2 not met.

This export cannot be processed because it combines two owners into one statement. The procedure requires exactly one owner per run. Process each owner separately:
- Prepare one export for Marcus Webb alone (units 12A, 12B).
- Prepare one export for Dana Whitfield alone (unit 3A).

STOPPED - no draft produced. Multiple owners in export. Human action required.
