STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: NO. The export is headed "OWNER STATEMENT - COMBINED" and
    the OWNER column carries two different owners: Marcus Webb (lines 12A, 12B,
    management fee 350.00, maintenance 180.00) and Dana Whitfield (line 3A,
    management fee 168.00, pest control 95.00). It also states "Properties
    covered: 2", against a configured 1 property per export. Only Marcus Webb is
    on the approved owner list.
 3. Fee basis configured: YES, 8% of base rent collected, base rent only. It
    cannot be confirmed against this owner's agreement while two owners are mixed
    into one export.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 5,322.00. Note that
    these totals are combined across both owners, so no owner's own balances are
    stated.
GATE FAILED on item 2.

WHAT I NEED
 Re-run the export for ONE owner only, with that owner's own beginning balance,
 ending balance, income, expenses and distributions. Which owner is this
 statement for: Marcus Webb, or Dana Whitfield? Dana Whitfield is not on the
 approved owner list, so a single-owner export for Marcus Webb is what I can work
 from.

 I have not inventoried, cross-checked, explained or drafted anything, because
 the gate did not pass.

STOPPED - no draft produced. Export covers two owners. Human action required.
