STEP 0 - GATE
 1. Reconciled and closed: NO. The export states "Status: OPEN - NOT YET RECONCILED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and other
    non-base-rent items excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 1,202.60.
GATE FAILED on item 1.

WHAT I NEED
 Confirmation that the July 2026 period has been reconciled and closed, and a
 re-export showing that status. I cannot run on an open month, because any figure
 in it can still change after I have explained it to the owner.

No inventory, no cross-check, and no draft have been produced.

STOPPED - no draft produced. Month not reconciled or closed. Human action required.
