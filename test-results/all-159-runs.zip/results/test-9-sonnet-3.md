STEP 0 - GATE
 1. Reconciled and closed: YES, stated ("Status: RECONCILED / CLOSED").
 2. Exactly one owner: NO. This export is titled "OWNER STATEMENT - COMBINED"
    and its line items belong to two different owners: Marcus Webb (lines
    2026-07-03, 2026-07-02, 2026-07-31 management fee, 2026-07-18) and Dana
    Whitfield (lines 2026-07-05, 2026-07-31 management fee, 2026-07-12).
    Marcus Webb is on the approved owners list, but this export is not
    limited to him alone.
 3. Fee basis configured: the operator config states 8% of base rent
    collected, base rent only. Not evaluated further because Gate item 2
    already fails.
 4. Period, beginning balance, and ending balance all stated: YES (Period
    2026-07-01 to 2026-07-31, Beginning balance 1,240.00, Ending balance
    5,322.00). Not evaluated further because Gate item 2 already fails.

GATE FAILED - condition 2: the export covers more than one owner
(Marcus Webb and Dana Whitfield combined), which also violates
never_list item 11 ("Run on more than one owner at a time"). Per
Step 0, no inventory, no cross-check, and no draft are produced. A
single-owner export for Marcus Webb only is needed before this
procedure can run.

STOPPED - no draft produced. Export covers two owners, not one. Human action required.
