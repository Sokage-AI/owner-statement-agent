STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list.
 3. Fee basis configured: YES, 8% of base rent collected, late fees, pet rent and
    application fees excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-05-01 to
    2026-05-31, beginning 480.00, ending -612.00.
GATE PASSED.

STEP 1 - INVENTORY
 2026-05-03 | Rent received | May rent | 12A | Income | 1,450.00
 2026-05-31 | Management fee | 8% of rent collected | 12A | Expense | 116.00
 2026-05-11 | Emergency plumbing - Ridgeline | Burst supply line, water damage | 12A | Expense | 2,192.50
 2026-05-22 | Water / sewer - City Utils | May billing | 12A | Expense | 88.50
 2026-05-05 | Landscaping - GreenSpan | Monthly grounds contract | 12A | Expense | 145.00
No MISSING fields.

STEP 2 - CROSS-CHECK
2a. COUNT. 5 line items: 1 Income, 4 Expense, 0 Distribution. 1 + 4 + 0 = 5. Matches.
2b/2c. ENUMERATE AND SUBTOTAL.
  INCOME:
    1,450.00
    1,450.00 = 1,450.00
  EXPENSES:
    116.00
    2,192.50
    88.50
    145.00
    116.00 + 2,192.50 + 88.50 + 145.00 = 2,542.00
  DISTRIBUTIONS:
    No distribution line items in the export.
    Enumerated distributions = 0.00
2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
  Income 1,450.00 against stated 1,450.00. Match.
  Expenses 2,542.00 against stated 2,542.00. Match.
  Distributions 0.00 against stated 0.00. Match.
2e. BALANCE EQUATION.
  480.00 + 1,450.00 - 2,542.00 - 0.00 = -612.00
2f. COMPARE. Derived -612.00 against stated -612.00. Difference 0.00, within tolerance.
2g. CROSS-CHECK PASSED - derived -612.00 matches stated -612.00.

STEP 3 - EXPLANATIONS
 Management fee 116.00 - the monthly fee, stated in the memo as 8% of rent collected.
 Emergency plumbing 2,192.50 - a burst supply line with water damage, unit 12A,
   Ridgeline.
 Water / sewer 88.50 - the May billing from City Utils.
 Landscaping 145.00 - the monthly grounds contract, GreenSpan.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - negative owner balance - -612.00 - confirm how the shortfall is to be covered
 and whether the owner has been told before this statement goes out.
 FLAG - single expense at or above the 1,000.00 review level - 2,192.50, emergency
 plumbing 2026-05-11 - check the invoice, the scope of the water damage work, and
 whether any part of it is insurable or recoverable.
 FLAG - ending balance below the 300.00 reserve floor - -612.00 - the reserve is not
 just short, it is overdrawn; decide what happens before June expenses land.

 Context I could not check: the statement header reads "Marcus Webb (Unit 12A only)",
 so I cannot tell from this export whether Marcus Webb holds other units whose
 balances sit outside it. The vendor on the 2,192.50 plumbing line is named
 "Ridgeline", which is also the operator name on the sign-off; the export does not
 say whether these are the same party.

STEP 5 - OWNER UPDATE

 May ended at -612.00. The account is overdrawn, and the reason is a single
 emergency: a burst supply line on the 11th, with water damage, at 2,192.50.

 Beginning balance: 480.00
 Income: 1,450.00
 Expenses: 2,542.00
 Distribution: 0.00
 Ending balance: -612.00

 Where the 2,542.00 went:
  - Emergency plumbing, 2,192.50. A burst supply line and the resulting water damage
    at 12A, on 2026-05-11.
  - Landscaping, 145.00. The monthly grounds contract.
  - Management fee, 116.00. Eight percent of rent collected.
  - Water and sewer, 88.50. The May billing from City Utils.

 There was no distribution in May. The 1,450.00 of rent did not cover the month's
 costs, so the balance went from 480.00 to -612.00.

 What needs your attention before next month: the -612.00 has to be settled, and the
 account is below the 300.00 reserve we normally hold, so June's costs have nothing
 sitting behind them. We will come back to you on both.

 Ridgeline Property Management

STEP 6 - LIKELY QUESTIONS
 1. Why is the balance negative? May brought in 1,450.00 and cost 2,542.00. Starting
    from 480.00, that leaves -612.00.
 2. What was the 2,192.50 for? A burst supply line and the water damage it caused at
    12A, on 2026-05-11.
 3. Why was there no distribution? Distributions for the month were 0.00. There was
    nothing left to send after the 2,542.00 of expenses.

DRAFT - not sent. 3 flags open. Human review required before release.
