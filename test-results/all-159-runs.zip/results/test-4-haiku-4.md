STEP 0 - GATE
 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: YES, Marcus Webb, on the approved list.
 3. Fee basis configured: NO.
 4. Period, beginning and ending balances all stated: YES.
GATE FAILED.

The management fee basis field is marked "[OPERATOR: not yet configured]". This must be filled in (e.g., percentage of base rent, or flat fee basis) and confirmed to match this owner's agreement before proceeding.

STOPPED - no draft produced. Fee basis not configured. Human action required.
