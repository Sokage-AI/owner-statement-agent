STEP 0 - GATE
 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: YES, Marcus Webb, Unit 12A, on the approved list.
 3. Fee basis configured: YES, 8% of base rent collected.
 4. Period, beginning and ending balances all stated: YES.
GATE PASSED.

STEP 1 - INVENTORY
 2026-05-03 | Rent received | May rent | 12A | Income | 1,450.00
 2026-05-31 | Management fee | 8% of rent collected | 12A | Expense | 116.00
 2026-05-11 | Emergency plumbing - Ridgeline | Burst supply line, water damage | 12A | Expense | 2,192.50
 2026-05-22 | Water / sewer - City Utils | May billing | 12A | Expense | 88.50
 2026-05-05 | Landscaping - GreenSpan | Monthly grounds contract | 12A | Expense | 145.00
No MISSING fields.

STEP 2 - CROSS-CHECK
2a. COUNT. 5 line items: 1 Income, 4 Expenses, 0 Distributions. 1 + 4 + 0 = 5. Matches.
2b/2c. ENUMERATE AND SUBTOTAL.
  INCOME:        1,450.00 = 1,450.00
  EXPENSES:      116.00 + 2,192.50 + 88.50 + 145.00 = 2,542.00
  DISTRIBUTIONS: (none) = 0.00
2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
  Income 1,450.00 against stated 1,450.00. Match.
  Expenses 2,542.00 against stated 2,542.00. Match.
  Distributions 0.00 against stated 0.00. Match.
2e. BALANCE EQUATION.
  480.00 + 1,450.00 - 2,542.00 - 0.00 = -612.00
2f. COMPARE. Derived -612.00 against stated -612.00. Difference 0.00, within tolerance.
2g. CROSS-CHECK PASSED - derived -612.00 matches stated -612.00.

STEP 3 - EXPLANATIONS
 Management fee 116.00 - the monthly fee, 8% of the 1,450.00 base rent collected.
 Emergency plumbing 2,192.50 - burst supply line, water damage, Ridgeline.
 Water / sewer 88.50 - May billing, City Utils.
 Landscaping 145.00 - monthly grounds contract, GreenSpan.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.
 FLAG - negative owner balance - -612.00 - the account is negative. No funds available for distribution. A human must determine next steps and inform the owner.
 FLAG - single expense at or above review level - 2,192.50 - emergency plumbing charge exceeds the 1,000.00 absolute review threshold. A human must verify the work was authorized and the amount is accurate.

STEP 5 - OWNER UPDATE
 May produced a negative balance. The burst pipe in 12A cost 2,192.50 in emergency plumbing, and that exceeded all income and reserves for the month. The account now carries an owed balance of 612.00.

 Beginning balance: 480.00
 Income: 1,450.00
 Expenses: 2,542.00
 Distribution: 0.00
 Ending balance: -612.00

 Where the 2,542.00 went:
  - Management fee, 116.00. Eight percent of the 1,450.00 of base rent collected.
  - Emergency plumbing, 2,192.50. Burst supply line and water damage, Ridgeline.
  - Water / sewer, 88.50. May billing, City Utils.
  - Landscaping, 145.00. Monthly grounds contract, GreenSpan.

 The emergency repair consumed the full month's rent and the 480.00 reserve. You will need to discuss funding this negative balance.

STEP 6 - LIKELY QUESTIONS
 1. Why is the balance negative? A burst supply line requiring 2,192.50 in emergency plumbing exceeded the 480.00 reserve and the 1,450.00 rent for the month.
 2. What happens now? The property is in a negative position until funds are available to cover the 612.00 shortfall. Your manager will contact you about resolution.
 3. Is this a one-time emergency? The water damage and plumbing repair were unexpected. Ongoing maintenance is budgeted separately.

DRAFT - not sent. 2 flags open. Human review required before release.
