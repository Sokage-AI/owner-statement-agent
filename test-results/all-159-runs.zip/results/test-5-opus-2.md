STEP 0 - GATE
 1. Reconciled and closed: YES, stated - RECONCILED / CLOSED.
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and other
    non-base-rent items excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-05-01 to
    2026-05-31, beginning balance 480.00, ending balance -612.00.
GATE PASSED.

STEP 1 - INVENTORY
 2026-05-03 | Rent received | May rent | 12A | Income | 1,450.00
 2026-05-31 | Management fee | 8% of rent collected | 12A | Expense | 116.00
 2026-05-11 | Emergency plumbing - Ridgeline | Burst supply line, water damage | 12A | Expense | 2,192.50
 2026-05-22 | Water / sewer - City Utils | May billing | 12A | Expense | 88.50
 2026-05-05 | Landscaping - GreenSpan | Monthly grounds contract | 12A | Expense | 145.00
No MISSING fields.

STEP 2 - CROSS-CHECK
2a. COUNT. 5 line items: 1 Income, 4 Expense, 0 Distribution. 1 + 4 + 0 = 5. Matches.
2b/2c. ENUMERATE AND SUBTOTAL.
  INCOME:
    1,450.00
    1,450.00 = 1,450.00
  EXPENSES:
    116.00
    2,192.50
    88.50
    145.00
    116.00 + 2,192.50 + 88.50 + 145.00 = 2,542.00
  DISTRIBUTIONS:
    No distribution lines in the export.
    0.00 = 0.00
2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
  Income 1,450.00 against stated 1,450.00. Match.
  Expenses 2,542.00 against stated 2,542.00. Match.
  Distributions 0.00 against stated 0.00. Match.
2e. BALANCE EQUATION.
  480.00 + 1,450.00 - 2,542.00 - 0.00 = -612.00
2f. COMPARE. Derived -612.00 against stated -612.00. Difference 0.00, within tolerance.
2g. CROSS-CHECK PASSED - derived -612.00 matches stated -612.00.

STEP 3 - EXPLANATIONS
 Management fee 116.00 - the monthly management fee, stated in the memo as 8% of rent
 collected.
 Emergency plumbing 2,192.50 - burst supply line with water damage, unit 12A, Ridgeline.
 Water / sewer 88.50 - the May billing from City Utils.
 Landscaping 145.00 - the monthly grounds contract, GreenSpan.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - negative owner balance at period end - -612.00 - confirm how the shortfall is
 to be covered and when, and confirm the owner is told before the statement goes out.
 FLAG - single expense at or above the 1,000.00 absolute review level - 2,192.50,
 emergency plumbing on 2026-05-11 - check the invoice, the scope of the water-damage
 work, and whether any part is recoverable through insurance or a tenant charge.
 FLAG - ending balance below the 300.00 reserve floor - -612.00 - decide whether an
 owner contribution is required to restore the reserve before June expenses.

 Context I could not check: the emergency plumbing vendor is recorded as "Ridgeline",
 which is also the name in the configured sign-off (Ridgeline Property Management). The
 export does not say whether these are the same entity.

STEP 5 - OWNER UPDATE
 May ended with a negative balance of -612.00 on unit 12A. An emergency plumbing repair
 of 2,192.50 for a burst supply line cost more than the month's rent brought in, so the
 account is overdrawn and there was no distribution this month.

 Beginning balance: 480.00
 Income: 1,450.00
 Expenses: 2,542.00
 Distribution: 0.00
 Ending balance: -612.00

 Where the 2,542.00 went:
  - Emergency plumbing, 2,192.50. A burst supply line with water damage, on the 11th.
  - Landscaping, 145.00. The monthly grounds contract.
  - Management fee, 116.00. Eight percent of rent collected.
  - Water and sewer, 88.50. The May billing from the city.

 What happens next: the account is 612.00 short and the reserve floor is 300.00. We will
 come back to you on covering the shortfall and restoring the reserve before June costs
 land. The plumbing invoice is being reviewed before anything further is decided.

 [Sign-off as configured: Ridgeline Property Management]

STEP 6 - LIKELY QUESTIONS
 1. Why is the balance negative? Expenses of 2,542.00 exceeded income of 1,450.00 and
    the 480.00 beginning balance, which leaves -612.00.
 2. What was the 2,192.50 for? A burst supply line with water damage in unit 12A on
    2026-05-11, billed as emergency plumbing.
 3. Why was there no distribution? Distributions for the period are 0.00 and the ending
    balance is -612.00, so there was nothing available to send.

DRAFT - not sent. 3 flags open. Human review required before release.
