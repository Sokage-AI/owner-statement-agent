STEP 0 - GATE
 1. Reconciled and closed: YES, stated RECONCILED / CLOSED.
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees, pet rent and
    application fees excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-05-01 to
    2026-05-31, beginning 480.00, ending -612.00.
GATE PASSED.

STEP 1 - INVENTORY
 2026-05-03 | Rent received | May rent | 12A | Income | 1,450.00
 2026-05-31 | Management fee | 8% of rent collected | 12A | Expense | 116.00
 2026-05-11 | Emergency plumbing - Ridgeline | Burst supply line, water damage | 12A | Expense | 2,192.50
 2026-05-22 | Water / sewer - City Utils | May billing | 12A | Expense | 88.50
 2026-05-05 | Landscaping - GreenSpan | Monthly grounds contract | 12A | Expense | 145.00
No MISSING fields.

STEP 2 - CROSS-CHECK
2a. COUNT. 5 line items: 1 Income, 4 Expense, 0 Distribution. 1 + 4 + 0 = 5. Matches.
2b. ENUMERATE.
  INCOME:
    1,450.00
  EXPENSES:
    116.00
    2,192.50
    88.50
    145.00
  DISTRIBUTIONS:
    (no distribution lines in the export)
2c. SUBTOTAL.
  INCOME:        1,450.00 = 1,450.00
  EXPENSES:      116.00 + 2,192.50 + 88.50 + 145.00 = 2,542.00
  DISTRIBUTIONS: no lines = 0.00
2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
  Income 1,450.00 against stated 1,450.00. Match.
  Expenses 2,542.00 against stated 2,542.00. Match.
  Distributions 0.00 against stated 0.00. Match.
2e. BALANCE EQUATION.
  480.00 + 1,450.00 - 2,542.00 - 0.00 = -612.00
2f. COMPARE. Derived -612.00 against stated -612.00. Difference 0.00, within tolerance.
2g. CROSS-CHECK PASSED - derived -612.00 matches stated -612.00.

STEP 3 - EXPLANATIONS
 Management fee 116.00 - the monthly fee, memo states 8% of rent collected.
 Emergency plumbing 2,192.50 - burst supply line and water damage, Ridgeline.
 Water / sewer 88.50 - May billing, City Utils.
 Landscaping 145.00 - monthly grounds contract, GreenSpan.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - Negative owner balance - -612.00 - the owner account ends the period owing.
 Confirm how this shortfall is to be covered and what the owner is told about it before
 anything is released.
 FLAG - Ending balance below the reserve floor - -612.00 against a 300.00 reserve floor -
 confirm the reserve top-up amount and timing.
 FLAG - Single expense at or above the 1,000.00 absolute review level - 2,192.50,
 emergency plumbing on 2026-05-11 - confirm the work order, the invoice, owner
 authorisation for an emergency of this size, and whether the water damage is an
 insurance matter.

 Context I could not check: the emergency plumbing vendor is named "Ridgeline", which is
 also the operator's own name in the sign-off, and the management fee memo says "8% of
 rent collected" where the configured basis is 8% of base rent collected.

STEP 5 - OWNER UPDATE
 May ends with a negative balance of -612.00 on your account. That is because an
 emergency plumbing repair of 2,192.50 came in above the month's rent. No distribution
 was made this month.

 Beginning balance: 480.00
 Income: 1,450.00
 Expenses: 2,542.00
 Distribution: 0.00
 Ending balance: -612.00

 Where the 2,542.00 went:
  - Emergency plumbing, 2,192.50. A burst supply line and water damage, on the 11th.
  - Landscaping, 145.00. The monthly grounds contract.
  - Management fee, 116.00. The memo records this as 8% of rent collected.
  - Water and sewer, 88.50. May billing.

 What this means: the account is 612.00 short, and it is below the 300.00 reserve level.
 We will be in touch about covering the shortfall and restoring the reserve. The plumbing
 repair and the water damage are being reviewed by a person here before anything further
 is decided.

 [Sign-off as configured: Ridgeline Property Management]

STEP 6 - LIKELY QUESTIONS
 1. Why is the balance -612.00? Expenses of 2,542.00 exceeded the 1,450.00 of rent
    received, against a beginning balance of 480.00.
 2. What was the 2,192.50 for? The export records it as a burst supply line with water
    damage, on 2026-05-11, by Ridgeline.
 3. Why was there no distribution? Distributions are stated as 0.00 for the period; the
    month's expenses were larger than the month's income.

DRAFT - not sent. 3 flags open. Human review required before release.
