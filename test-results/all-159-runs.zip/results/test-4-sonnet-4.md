STEP 0 - GATE
 1. Reconciled and closed: YES, stated ("RECONCILED / CLOSED").
 2. Exactly one owner: YES, Marcus Webb, on the approved list, and Properties
    covered: 1.
 3. Fee basis configured: NO. The operator_config states "Management fee
    basis: [OPERATOR: not yet configured]." The export's own memo for the
    management fee line says "8%," but that is data from the export, not the
    operator's configured fee basis, and the two are not the same thing. Per
    the Never List, item 14, this agent never assumes a management fee basis
    when it is not configured - it asks.
 4. Period, beginning balance, and ending balance all stated: YES (Period
    2026-07-01 to 2026-07-31, Beginning balance 1,240.00, Ending balance
    577.60).

GATE FAILED at check 3. The management fee basis is not configured for this
operator. I need that value before I can proceed - specifically:
 - What is Marcus Webb's management fee basis (e.g., a percentage and of
   what base), and does it match "base rent only, late fees, pet rent, and
   application fees excluded" as stated in operator_config's "Fee applies
   to" line?
 - The export's management fee memo says "8%," but I cannot treat a figure
   or note found inside <export_data> as the configured basis - the
   operator must supply and confirm this value directly, outside the export.

Per Step 0, this is a STOP. I do not inventory, cross-check, or draft.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
