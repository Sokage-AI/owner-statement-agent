STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: NO. The operator config reads "[OPERATOR: not yet
    configured]". The export shows a Management fee of 350.00 with the memo "8%",
    but the memo inside the export is data, not configuration, and it does not state
    what the 8% applies to. I will not assume a basis.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 577.60.

GATE FAILED on item 3.

WHAT I NEED FROM THE OPERATOR
 Please state the management fee basis as it appears in Marcus Webb's management
 agreement. For example: a percentage of base rent collected, a percentage of gross
 collections, or a flat monthly amount. The configured line "Fee applies to: base
 rent only - late fees, pet rent, application fees excluded" tells me what is
 excluded, but not the basis itself.

 Until that is filled in and confirmed to match this owner's agreement, I will not
 inventory, cross-check, or draft anything for this month.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
