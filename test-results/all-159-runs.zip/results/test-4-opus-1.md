STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: NO. The operator config reads "[OPERATOR: not yet
    configured]". The export shows a Management fee of 350.00 with the memo "8%",
    but I cannot take a fee basis from the export data, and I will not assume one.
    I need the configured basis, and confirmation that it matches Marcus Webb's
    management agreement, before I can proceed.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 577.60.
GATE FAILED on item 3.

WHAT I NEED
 Fill in the management fee basis in the operator config, and confirm it matches
 this owner's agreement. Fee applies to base rent only - late fees, pet rent and
 application fees excluded.

No inventory, no cross-check and no draft has been produced.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
