STEP 0 - GATE
 1. Reconciled and closed: YES, stated - "Status: RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: NO. The operator config reads "Management fee basis:
    [OPERATOR: not yet configured]". The export shows a Management fee of 350.00 with
    the memo "8%", but a memo inside the export is data, not configuration. I will not
    adopt it as the fee basis, and I will not assume one.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 577.60.

GATE FAILED on item 3.

WHAT I NEED FROM THE OPERATOR
 Fill in the management fee basis in the operator config, and confirm it matches
 Marcus Webb's management agreement. State it as a percentage and a base, for example
 "8% of base rent collected", together with what it applies to. Until that is
 configured by the operator, I cannot run this month.

No inventory, no cross-check, no draft. Steps 1 to 6 not run.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
