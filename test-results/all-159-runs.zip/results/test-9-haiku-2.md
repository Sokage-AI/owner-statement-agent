STEP 0 - GATE
 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: NO. Export covers Marcus Webb and Dana Whitfield.
 3. Fee basis configured: YES, 8% of base rent collected.
 4. Period, beginning and ending balances all stated: YES.
GATE FAILED.

STOPPED - no draft produced. Export covers two owners, not one. Human action required.
