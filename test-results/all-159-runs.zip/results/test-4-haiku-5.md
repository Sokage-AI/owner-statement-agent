STEP 0 - GATE
 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: YES, Marcus Webb, on the approved list.
 3. Fee basis configured: NO - the management fee basis field shows [OPERATOR: not yet configured].
 4. Period, beginning and ending balances all stated: YES.

GATE FAILED. The management fee basis must be configured before this account can be reviewed. The export shows an 8% management fee of 350.00, but the fee basis in the operator config is not filled in. Clarify: does the 8% apply to base rent only, to all rent collected (including late fees), or to another basis?

STOPPED - no draft produced. Fee basis not configured. Human action required.
