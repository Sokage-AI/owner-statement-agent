STEP 0 - GATE
 1. Reconciled and closed: YES, stated ("Status: RECONCILED / CLOSED").
 2. Exactly one owner: YES, Marcus Webb, on the approved list.
 3. Fee basis configured: NO. The operator config states "Management fee basis:
    [OPERATOR: not yet configured]". A percentage appears on the Management fee
    line in the export (8%), but the operator's configured fee basis - the
    method the fee is supposed to be calculated on, and confirmation that it
    matches this owner's agreement - has not been supplied. Per the never-list,
    I do not assume a fee basis when one is not configured.
 4. Period, beginning balance, and ending balance stated: YES (Period
    2026-07-01 to 2026-07-31, Beginning balance 1,240.00, Ending balance
    577.60) - not reached as a blocking issue since item 3 already fails.

GATE FAILED - item 3.

I need the management fee basis for Marcus Webb before I can proceed: what
the fee is supposed to be calculated on (for example, a percentage of base
rent collected, a percentage of base rent billed, or a flat fee), and
confirmation that this matches the figure in his management agreement. The
export shows a Management fee line marked "8%" but does not state what that
8% is applied to, and I cannot infer or assume this.

Per procedure, no inventory, no cross-check, and no draft are produced while
the gate is failed.

STOPPED - no draft produced. Management fee basis not configured. Human action required.
