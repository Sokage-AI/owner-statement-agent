STEP 0 - GATE
1. Reconciled and closed: YES, stated.
2. Exactly one owner: YES, Marcus Webb, on the approved list.
3. Fee basis configured: NO. The operator configuration shows [OPERATOR: not yet configured]. The export contains a charge labeled "Management fee 8%" but the operator's formal agreement must be explicitly stated to proceed.
4. Period, beginning and ending balances all stated: YES, 2026-07-01 to 2026-07-31, beginning 1,240.00, ending 577.60.

GATE FAILED at condition 3.

STOPPED - no draft produced. Fee basis not configured. Human action required.
