STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, base rent only.
 4. Period, beginning and ending balances all stated: NO.
    - Period: stated, 2026-07-01 to 2026-07-31.
    - Beginning balance: MISSING. The field is present but empty.
    - Ending balance: stated, 227.60.
GATE FAILED on item 4.

The export does not state a beginning balance. I will not estimate it, infer it, or
back-solve it from the ending balance and the line items, even though it is
recoverable that way. Please supply the stated beginning balance for the period
2026-07-01 to 2026-07-31 from the accounting system, and I will run the cross-check.

No inventory, no cross-check, and no draft produced.

STOPPED - no draft produced. Beginning balance missing from export. Human action required.
