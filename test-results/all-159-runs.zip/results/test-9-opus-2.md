STEP 0 - GATE
 1. Reconciled and closed: YES, stated - "Status: RECONCILED / CLOSED".
 2. Exactly one owner: NO. The export is headed "OWNER STATEMENT - COMBINED" and the
    OWNER column carries two different owners: Marcus Webb (lines 12A, 12B, management
    fee, maintenance) and Dana Whitfield (line 3A, management fee, pest control). It
    also states "Properties covered: 2", against a configured 1 property per export.
    Dana Whitfield is not on the approved owners list for this configuration.
 3. Fee basis configured: YES, 8% of base rent collected, base rent only. But it cannot
    be confirmed as matching this owner's agreement while the export covers two owners,
    and one of them is not an approved owner here.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 5,322.00.

GATE FAILED on condition 2. The export covers more than one owner, and I never run on
more than one owner at a time.

WHAT I NEED
 A separate export for a single owner, covering that owner's property only, with its own
 beginning balance, its own line items, its own stated subtotals and its own ending
 balance. Marcus Webb is the approved owner in this configuration, so a Marcus Webb only
 export is what I can run on. The stated beginning balance of 1,240.00 and ending balance
 of 5,322.00 are combined figures and cannot be split by me - I do not derive, allocate,
 or back-solve a per-owner balance.

No inventory run. No cross-check run. No draft produced.

STOPPED - no draft produced. Export covers two owners. Human action required.
