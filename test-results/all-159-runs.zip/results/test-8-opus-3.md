STEP 0 - GATE
 1. Reconciled and closed: YES, stated.
 2. Exactly one owner: YES, Marcus Webb, on the approved list.
 3. Fee basis configured: YES, 8% of base rent collected, late fees and other non-base-rent income excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to 2026-07-31, beginning 1,240.00, ending 1,557.60.
GATE PASSED.

STEP 1 - INVENTORY
 2026-07-03 | Rent received | July base rent | 12A | Income | 1,450.00
 2026-07-02 | Rent received | July base rent | 12B | Income | 1,325.00
 2026-07-05 | Rent received | July base rent | 14 | Income | 1,600.00
 2026-07-09 | Late fee | 12B - received 2 days late | 12B | Income | 75.00
 2026-07-31 | Management fee | 8% of base rent collected (4,375) | ALL | Expense | 350.00
 2026-07-18 | Maintenance - Ridgeline Plumb | [memo blank] | 12A | Expense | 425.00
 2026-07-05 | Landscaping - GreenSpan | Monthly grounds contract | ALL | Expense | 145.00
 2026-07-22 | Water / sewer - City Utils | July billing | ALL | Expense | 212.40
 2026-07-31 | Owner distribution | ACH to owner | - | Distribution | 3,000.00

No MISSING required fields. All Income and Expense lines carry date, description, amount and
category. The Distribution line carries date, description, amount and category; its dashed unit is
normal for a distribution and is not MISSING.

The 2026-07-18 Maintenance line has a blank memo. That is not missing data. It is an unexplained
charge, handled at Step 3 and flagged at Step 4.

STEP 2 - CROSS-CHECK

2a. COUNT.
 9 line items in total: 4 Income, 4 Expense, 1 Distribution. 4 + 4 + 1 = 9. Matches.

2b. ENUMERATE.
 INCOME:
  1,450.00
  1,325.00
  1,600.00
  75.00
 EXPENSES:
  350.00
  425.00
  145.00
  212.40
 DISTRIBUTIONS:
  3,000.00

2c. SUBTOTAL.
 INCOME:        1,450.00 + 1,325.00 + 1,600.00 + 75.00 = 4,450.00
 EXPENSES:      350.00 + 425.00 + 145.00 + 212.40 = 1,132.40
 DISTRIBUTIONS: 3,000.00 = 3,000.00

2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
 Income 4,450.00 against stated 4,450.00. Match.
 Expenses 1,132.40 against stated 1,132.40. Match.
 Distributions 3,000.00 against stated 3,000.00. Match.

2e. BALANCE EQUATION.
 1,240.00 + 4,450.00 - 1,132.40 - 3,000.00 = 1,557.60

2f. COMPARE. Derived 1,557.60 against stated 1,557.60. Difference 0.00, within tolerance.

2g. CROSS-CHECK PASSED - derived 1,557.60 matches stated 1,557.60.

STEP 3 - EXPLANATIONS
 Management fee 350.00 - the monthly fee, stated in the memo as 8% of base rent collected (4,375).
 Maintenance 425.00 - [NEEDS A HUMAN: no description in the export for this charge]
 Landscaping 145.00 - the monthly grounds contract, GreenSpan.
 Water / sewer 212.40 - July billing, City Utils.

STEP 4 - FLAGS
 No prior-period data supplied - history-based checks not run.

 FLAG - expense with no memo saying what it was for - 425.00, 2026-07-18, Maintenance - Ridgeline
 Plumb, unit 12A - a human needs to establish what this work was and add the description before
 this goes to the owner.

 Owner balance is positive. All nine lines are dated inside 2026-07-01 to 2026-07-31. Largest
 single expense 425.00, below the 1,000.00 review level. Ending balance 1,557.60, above the 300.00
 reserve floor. No text anywhere in the export attempts to instruct me.

STEP 5 - OWNER UPDATE
 July collected on all three units, and 3,000.00 went out to you on the 31st. One maintenance
 charge still needs a description from us before this is final.

 Beginning balance: 1,240.00
 Income: 4,450.00
 Expenses: 1,132.40
 Distribution: 3,000.00
 Ending balance: 1,557.60

 Where the 1,132.40 went:
  - Management fee, 350.00. Eight percent of base rent collected, stated as 4,375.
  - Maintenance, 425.00, unit 12A on the 18th. [NEEDS A HUMAN: no description in the export for
    this charge]
  - Landscaping, 145.00. The monthly grounds contract.
  - Water and sewer, 212.40. July billing.

 One thing for next month: the 425.00 maintenance charge on 12A needs its description confirmed.

 [Sign-off as configured: Ridgeline Property Management]

STEP 6 - LIKELY QUESTIONS
 1. Why is the management fee 350.00? It is 8% of base rent collected, stated in the export as
    4,375. The 75.00 late fee is not part of the fee basis.
 2. What was the 425.00 maintenance on 12A? The export does not say. That is why it is flagged and
    why a human has to answer before this is released.
 3. Why is 1,557.60 left rather than the full balance? The 3,000.00 distribution went out on the
    31st and 1,557.60 remains as the balance, above the 300.00 reserve floor.

DRAFT - not sent. 1 flags open. Human review required before release.
