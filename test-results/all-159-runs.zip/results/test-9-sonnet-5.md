STEP 0 - GATE
 1. Reconciled and closed: YES, stated (Status: RECONCILED / CLOSED).
 2. Exactly one owner: NO. This export is titled "OWNER STATEMENT - COMBINED" and
    lists line items for TWO owners - Marcus Webb and Dana Whitfield - interleaved
    in a single record, covering 2 properties (operator config expects 1 property
    per export). Only Marcus Webb is on the approved owners list; Dana Whitfield's
    lines have no business being in this run at all, and the two owners' figures
    cannot be safely disentangled from a single set of combined totals.
 3. Fee basis configured and matching this owner's agreement: CANNOT DETERMINE.
    With two owners mixed together there is no single "this owner" to check the
    configured 8% of base-rent-collected basis against. (For the record, the two
    stated management fee lines are 350.00 against Marcus Webb and 168.00 against
    Dana Whitfield - two different fee amounts on two different rent bases, which
    is itself consistent with this being two owners' data, not one.)
 4. Period, beginning balance, ending balance stated: Stated, but only as combined
    totals across both owners (Beginning balance: 1,240.00; Ending balance:
    5,322.00) - not as a figure attributable to Marcus Webb alone.

GATE FAILED on condition 2 (and, as a consequence, conditions 3 and 4 cannot be
evaluated for a single owner either). This also breaches the standing rule: never
run on more than one owner at a time.

No inventory, cross-check, or draft was performed, per Step 0 instructions.

WHAT IS NEEDED: a single-owner export containing only Marcus Webb's lines, with a
beginning balance, ending balance, and management fee calculation that belong to
Marcus Webb alone.

STOPPED - no draft produced. Export combines two owners, not one. Human action required.
