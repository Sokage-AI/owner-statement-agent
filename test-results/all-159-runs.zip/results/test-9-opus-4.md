STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: NO. The export is headed "OWNER STATEMENT - COMBINED" and
    states "Properties covered: 2". The OWNER column carries two different owners,
    Marcus Webb and Dana Whitfield. Only Marcus Webb is on the approved list. The
    configuration is one property per export; this export states two.
 3. Fee basis configured: YES, 8% of base rent collected, base rent only, late
    fees, pet rent and application fees excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 5,322.00.

GATE FAILED on item 2.

I cannot run on more than one owner at a time, and the stated totals and balances
in this export are combined across both owners. Splitting them would mean deriving
each owner's figures myself, which is a recomputation I will not perform.

WHAT I NEED
 - A separate export for Marcus Webb alone, covering 2026-07-01 to 2026-07-31,
   with his own stated beginning balance, total income, total expenses,
   distributions and ending balance as produced by the accounting system.
 - Confirmation of whether Dana Whitfield is an approved owner for this operator.
   She does not appear on the approved list in the configuration. If her statement
   is also needed, it runs as its own separate export.

No inventory, no cross-check and no draft have been produced.

STOPPED - no draft produced. Export covers two owners. Human action required.
