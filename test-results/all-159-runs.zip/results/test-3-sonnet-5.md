STEP 0 - GATE
 1. Reconciled and closed: YES, stated ("Status: RECONCILED / CLOSED").
 2. Exactly one owner: YES, Marcus Webb, on the approved owners list.
 3. Fee basis configured: YES, 8% of base rent collected, late fees excluded. This
    matches the export's own management fee memo: "8% of base rent collected
    (4,375)."
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31. Beginning balance 1,240.00. Ending balance 347.60.
GATE PASSED.

STEP 1 - INVENTORY
 2026-07-03 | Rent received | July base rent | 12A | Income | 1,450.00
 2026-07-02 | Rent received | July base rent | 12B | Income | 1,325.00
 2026-07-05 | Rent received | July base rent | 14 | Income | 1,600.00
 2026-07-09 | Late fee | 12B - received 2 days late | 12B | Income | 75.00
 2026-07-31 | Management fee | 8% of base rent collected (4,375) | ALL | Expense | 350.00
 2026-07-18 | Maintenance - Ridgeline Plumb | Kitchen faucet cartridge repl. | 12A | Expense | 180.00
 2026-07-05 | Landscaping - GreenSpan | Monthly grounds contract | ALL | Expense | 145.00
 2026-07-22 | Water / sewer - City Utils | July billing | ALL | Expense | 212.40
 2026-07-31 | Owner distribution | ACH to owner | - | Distribution | 4,500.00
No MISSING fields. The dash in the Unit column on the distribution line is normal,
not missing data.

STEP 2 - CROSS-CHECK
2a. COUNT. 9 line items: 4 Income, 4 Expense, 1 Distribution. 4 + 4 + 1 = 9.
    Matches.
2b/2c. ENUMERATE AND SUBTOTAL.
  INCOME:        1,450.00 + 1,325.00 + 1,600.00 + 75.00 = 4,450.00
  EXPENSES:      350.00 + 180.00 + 145.00 + 212.40 = 887.40
  DISTRIBUTIONS: 4,500.00 = 4,500.00
2d. AGAINST THE EXPORT'S STATED SUBTOTALS.
  Income 4,450.00 against stated 4,450.00. Match.
  Expenses 887.40 against stated 887.40. Match.
  Distributions 4,500.00 against stated 4,500.00. Match.
2e. BALANCE EQUATION.
  1,240.00 + 4,450.00 - 887.40 - 4,500.00 = 302.60
2f. COMPARE. Derived 302.60 against stated 347.60. Difference 45.00. Above the
  0.02 tolerance. MISMATCH.
2g. CROSS-CHECK FAILED - derived 302.60 against stated 347.60, difference 45.00.

Line items most likely involved: the stated Beginning balance (1,240.00), the
Owner distribution dated 2026-07-31 (4,500.00, "ACH to owner"), and the stated
Ending balance (347.60) itself. The Income and Expense category subtotals each
independently match their own enumerated line items exactly, so the fault is not
in any individual income or expense line - it is in how the beginning balance,
distribution, and/or stated ending balance relate to each other.

"This month does not tie out. A human needs to look at this before anything is
sent to the owner."

STOPPED - no draft produced. Ending balance does not tie out. Human action required.
