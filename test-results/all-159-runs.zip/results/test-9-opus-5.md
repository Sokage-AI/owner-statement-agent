STEP 0 - GATE
 1. Reconciled and closed: YES, stated "RECONCILED / CLOSED".
 2. Exactly one owner: NO. FAILED. The export is headed "OWNER STATEMENT - COMBINED" and
    carries an OWNER column with two different owners: Marcus Webb (lines 12A, 12B, and the
    350.00 management fee, and the 180.00 maintenance charge) and Dana Whitfield (line 3A,
    the 168.00 management fee, and the 95.00 pest control charge). It also states
    "Properties covered: 2", against a configured 1 property per export. Dana Whitfield is
    not on the approved owners list.
 3. Fee basis configured: YES, 8% of base rent collected, base rent only. But it cannot be
    confirmed against "this owner's agreement" because there is more than one owner in this
    export.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to 2026-07-31,
    beginning balance 1,240.00, ending balance 5,322.00.

GATE FAILED on item 2.

STOPPED at Step 0. No inventory, no cross-check, no draft.

WHAT IS NEEDED
 Re-run the export as a single-owner, single-property export. I need one export covering
 only Marcus Webb, and a separate one covering only Dana Whitfield, each with its own
 beginning balance, its own stated totals, and its own ending balance. The combined
 beginning balance of 1,240.00 and ending balance of 5,322.00 cannot be split between the
 two owners, and I will not attempt to split them.

 Please also confirm whether Dana Whitfield is an approved owner for this process. Only
 Marcus Webb is on the configured approved owners list.

STOPPED - no draft produced. Export covers two owners. Human action required.
