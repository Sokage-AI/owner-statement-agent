STEP 0 - GATE
 1. Reconciled and closed: NO. The export states "Status: OPEN - NOT YET RECONCILED".
 2. Exactly one owner: YES, Marcus Webb, on the approved list. Properties covered: 1.
 3. Fee basis configured: YES, 8% of base rent collected, late fees excluded.
 4. Period, beginning and ending balances all stated: YES. Period 2026-07-01 to
    2026-07-31, beginning balance 1,240.00, ending balance 1,202.60.
GATE FAILED on condition 1.

The month is not reconciled and closed, so I cannot run on it. I need confirmation
that July 2026 has been reconciled and closed, and a re-export showing that status,
before any inventory, cross-check or draft is produced.

No inventory performed. No cross-check performed. No draft produced.

STOPPED - no draft produced. Month not reconciled or closed. Human action required.
